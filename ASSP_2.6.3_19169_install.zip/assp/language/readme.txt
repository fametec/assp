Copy or rename your language file to assp.lng inside this folder and restart ASSP.
